import java.util.*;
public class Path {
    private int pathScore = 0;
    private ArrayList<Node> list = new ArrayList<Node>();

    public Path(){

    }

    public void add(Node n){
        this.list.add(n);
        this.pathScore += n.getScore();
    }

    public void printPath(){
        for (Node n: list){
            System.out.println(n.getInfo());
        }
    }
}
