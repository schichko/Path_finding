import java.util.*;

public class Node {
    final char[] goal = new char[] { '4', '3', '2', '1'};
    private Node next[] = new Node[] {null,null,null};
    private Node prev;
    private char order[];
    private boolean isGoal = false;
    private int score =0;

    public Node(char info[], Node prev) {
        this.order = info;
        //System.out.print("Making Node:");
        //System.out.println(this.order);
        //this.next = next;
        this.prev = prev;
        setScore();
        //System.out.println(score);
        if (Arrays.equals(this.order,goal)){
            this.isGoal = true;
            //System.out.println("Goal Node");
        }
        else {
            makeChildren();
        }
    }

    public void setInfo(char info[]) {
        this.order = info;
    }

    public void setScore() {
        for(int i = 0;i <4;i ++){
            if(this.order[i] == goal[i]){
                score ++;
            }
        }
    }

    public void setPrev(Node node) {
        prev = node;
    }

    public char[] getInfo() {
        return order;
    }

    public int getScore(){
        return this.score;
    }

    public boolean isGoal() {
        return isGoal;
    }

    public Node getNext(int n) {
        //System.out.println(n);
        if(n>2){
           System.out.println("Error n > 2");
        }
        return next[n];
    }

    public Node getPrev() {
        return prev;
    }

    public void makeChildren(){
        if(isGoal != true) {
            for (int i = 0; i < 3; i++) { //First |#### //Second #|### //Third ##|##
                char[] temp = new char[4];
                boolean alreadyDone = false;
                Node parentTemp = this;
                switch (i){
                    case 0:
                        temp[0] = this.order[3];    //Swap Bottom = Top
                        temp[1] = this.order[2];    //Swap Third = Second
                        temp[2] = this.order[1];    //Swap Second = Third
                        temp[3] = this.order[0];    //Swap Top = Bottom
                        //Check and make
                        //System.out.println(temp);
                        while((parentTemp != null) && (alreadyDone == false)){
                            //System.out.print("Parent Order:");
                            //System.out.println(parentTemp.order);
                            if(Arrays.equals(parentTemp.order,temp)){  //Must do this when comparing arrays, char.equals will not work
                                //System.out.println("Already Done");
                                alreadyDone = true;
                            }
                            else{
                                //System.out.println("We gucci");
                                parentTemp = parentTemp.prev;
                            }
                        }
                        if(alreadyDone == false){
                            Node n1 = new Node(temp,this);
                            this.next[0] = n1;
                        }
                        break;
                    case 1:
                        temp[0] = this.order[0];    //Bottom = Bottom
                        temp[1] = this.order[3];    //Third = First
                        temp[2] = this.order[2];    //Second = Second
                        temp[3] = this.order [1];    //First = Third
                        //Check and make
                        //System.out.println(temp);
                        while((parentTemp != null) && (alreadyDone == false)){
                            //System.out.print("Parent Order:");
                            //System.out.println(parentTemp.order);
                            if(Arrays.equals(parentTemp.order,temp)){  //Must do this when comparing arrays, char.equals will not work
                                //System.out.println("Already Done");
                                alreadyDone = true;
                            }
                            else{
                                //System.out.println("We gucci");
                                parentTemp = parentTemp.prev;
                            }
                        }
                        if(alreadyDone == false){
                            Node n1 = new Node(temp,this);
                            this.next[1] = n1;
                        }
                        break;
                    case 2:
                        temp[0] = this.order[0];
                        temp[1] = this.order[1];
                        temp[2] = this.order[3];
                        temp[3] = this.order[2];
                        //Check and make
                        //System.out.println(temp);
                        while((parentTemp != null) && (alreadyDone == false)){
                            //System.out.print("Parent Order:");
                            //System.out.println(parentTemp.order);
                            if(Arrays.equals(parentTemp.order,temp)){  //Must do this when comparing arrays, char.equals will not work
                                //System.out.println("Already Done");
                                alreadyDone = true;
                            }
                            else{
                                //System.out.println("We gucci");
                                parentTemp = parentTemp.prev;
                            }
                        }
                        if(alreadyDone == false){
                            Node n1 = new Node(temp,this);
                            this.next[2] = n1;
                        }
                        break;

                }
            }
        }
    }
}

