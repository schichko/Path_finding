//Bugs for later
//#1 - Crash if first input is 4321
//Error on 3421d
import java.util.*;

public class Main {
    static Node startN;
    static char[] b;
    static char[] mG;
    public static void main(String[] args) {
        char[] test1 = new char[] { '4', '3', '2', '1'};
        char[] test2 = new char[] { '4', '3', '2', '1'};
        System.out.println(Arrays.equals(test1,test2));

        boolean exit = false;
        Scanner reader = new Scanner(System.in);  // Reading from System.in
        while(exit == false) {
            System.out.println("Input an order for the pancakes (#) along with a character to determine the sorting algorithm(X),####X, or type exit to exit the program");
            System.out.println("d - Depth First Search, u - Uniform Cost Search, g - Greedy, a - A* :");
            String s = reader.next();
            b = s.toCharArray();    //For General Purpose
            mG = s.substring(0,(s.length() -1 )).toCharArray(); //For making the graph
            if(s.compareTo("exit") == 0){
                exit = true;
                reader.close();
            }
            else if(b.length == 5){         //#### is b[0] b[1] b[2] b[3]
                makeGraph();
                System.out.println("Out of Make Graph Ignore Below");
                switch(b[4]){
                    case 'd':
                        System.out.println("Depth First Search");
                        dfs();
                        break;
                    case 'u':
                        System.out.println("Uniform Cost Search");
                        break;
                    case 'g':
                        System.out.println("Greedy Search");
                        break;
                    case 'a':
                        System.out.println("A* Search");
                        break;
                    default:
                        System.out.println("Wrong type of search input");
                        break;


                }
            }
            else{
                System.out.println("Wrong input length try again");
            }
        }
    }

    public static void dfs(){
        boolean foundG = false;
        Path myPath = new Path();
        Node currentNode = startN;
        myPath.add(currentNode);
        while(foundG == false){
            Node temp = null;
            //System.out.println(currentNode.getInfo());
            for(int i = 0; i<3;i++){
                if(temp == null || (temp.getScore() < currentNode.getNext(i).getScore())){
                    temp = currentNode.getNext(i);
                }
            }

            currentNode = temp;
            myPath.add(currentNode);
            if(currentNode.isGoal() == true){
                foundG = true;
            }
        }
        myPath.printPath();
    }

    public static void makeGraph(){
        startN = new Node(mG,null);

        //printGraph(startN);
    }

    public static void printGraph(Node n1){
        System.out.print("Parent Node:");
        System.out.println(n1.getInfo());
        for(int i = 0; i < 3; i++){
            System.out.print("Child Node:");
            if(n1.getNext(i)!= null) {
                System.out.println(n1.getNext(i).getInfo());
                printGraph(n1.getNext(i));
            }


        }

    }

}
