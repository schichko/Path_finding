import java.util.*;

public class Fringe {
    private ArrayList<Node> myFringe = new ArrayList<Node>();

    public Fringe(){

    }

    public void addNode(Node n){
        myFringe.add(n);
    }

    public void removeNode(Node n){
        myFringe.remove(n);
    }


}
